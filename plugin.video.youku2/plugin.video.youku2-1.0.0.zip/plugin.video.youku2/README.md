youkuvideo
==========

About
-----
youkuvideo is a xbmc plugin, you can be play youku video online ,support all channels, Condition filter and stream type select.

几大特色：
1、插件支持全部过滤条件过滤视频，更精确的找到你想看的节目
2、支持视频搜索，优酷的搜索引擎能搜索全网（不仅仅优酷）的视频，你可以通过搜索精确的找到某个节目，如果优酷没有提供该节目（版权问题），那么他也会把其他地方的视频列出来，目前支持的播放源（优酷/土豆/搜狐/腾讯/爱奇艺/乐视/pps）
3、支持菜单缓存，实现菜单切换无停顿感（缓存24小时自动失效/也可以通过手动清除）

完全支持电影/电视/动漫/综艺节目搜索


写这个插件的目的完全是满足自己的需求，自我感觉用起来不错，希望能对大家也有帮助

另外如果你也是一个父亲，欢迎用我的插件给孩子放youku视频


Dependences
-----
youkuvideo dependences xbmcswift2
